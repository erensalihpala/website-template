package com.crm_project.model;

/**
 * AuthResponse
 * 
 * Giriş işlemi sonrası kullanıcıya döndürülen bilgileri temsil eder.
 */
public class AuthResponse {
    private final String jwt;

    public AuthResponse(String jwt) {
        this.jwt = jwt;
    }

    public String getJwt() {
        return jwt;
    }
}
