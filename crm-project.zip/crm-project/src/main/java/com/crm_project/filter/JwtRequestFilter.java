package com.crm_project.filter;

import com.crm_project.service.UserService;
import com.crm_project.util.JwtUtil;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
public class JwtRequestFilter extends OncePerRequestFilter {

    private final UserService userService;
    private final JwtUtil jwtUtil;

    public JwtRequestFilter(@Lazy UserService userService, JwtUtil jwtUtil) { // Döngüyü kırmak için @Lazy ekleniyor
        this.userService = userService;
        this.jwtUtil = jwtUtil;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        final String authorizationHeader = request.getHeader("Authorization");

        String username = null;
        String jwt = null;

        if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
            jwt = authorizationHeader.substring(7);
            username = jwtUtil.extractUsername(jwt);
        }

        if (username != null && jwtUtil.validateToken(jwt, username)) {
            UserDetails userDetails = userService.loadUserByUsername(username);
            // Authentication işlemleri...
        }

        if (request.getRequestURI().equals("/health") || request.getRequestURI().equals("/error")) {
            chain.doFilter(request, response);
            return;
        }

        chain.doFilter(request, response);
    }
}
